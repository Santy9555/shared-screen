
import Navbar from '../components/Navbar.vue';
export default function Home() {
    return (
        <div>
            <Navbar />
            <h1>Bienvenido al Software Educativo</h1>
        </div>
    );
}
