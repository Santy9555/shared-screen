
export default function Edit() {
    return <h1>Página para Editar Contenido</h1>;
}
