
export default function Create() {
    return <h1>Página para Crear Contenido</h1>;
}
