
export default function Export() {
    return <h1>Página para Exportar Contenido</h1>;
}
