
export default function Share() {
    return <h1>Página para Compartir Contenido</h1>;
}
