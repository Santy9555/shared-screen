
export default function Comment() {
    return <h1>Página para Comentar Contenido</h1>;
}
