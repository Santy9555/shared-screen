
<template>
    <aside>
        <h3>Opciones</h3>
        <ul>
            <li>Herramienta 1</li>
            <li>Herramienta 2</li>
        </ul>
    </aside>
</template>

<style scoped>
aside {
    background-color: #f4f4f4;
    padding: 1rem;
    border-right: 1px solid #ddd;
}
</style>
