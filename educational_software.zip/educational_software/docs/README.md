
# Proyecto Educativo
Este proyecto es una plataforma para la creación y colaboración de contenido educativo.

## Tecnologías Usadas
- Frontend: Next.js, Vue.js
- Backend: Node.js, MongoDB
