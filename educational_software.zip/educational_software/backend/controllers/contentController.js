
exports.createContent = (req, res) => {
    res.send('Creando contenido');
};
