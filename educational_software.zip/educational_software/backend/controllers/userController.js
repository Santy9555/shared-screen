
exports.getAllUsers = (req, res) => {
    res.send('Obteniendo todos los usuarios');
};
